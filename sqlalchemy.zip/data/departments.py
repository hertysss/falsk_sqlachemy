import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase


class Departaments(SqlAlchemyBase):
    __tablename__ = 'departaments'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    title = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    chief = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    members = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    email = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    users = orm.relationship("User")

__factory = None
db_file = input()
global_init(db_file)
db_sess = create_session()
for user in db_sess.query(User).filter(User.departament.id == 1, User.speciality.notilike("%engineer%"),
                                       User.position.notilike("%engineer%")):
    print(user.id)