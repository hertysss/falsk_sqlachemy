from flask import Flask, render_template, redirect
from data import db_session
from data.users import User
from data.jobs import Job
from forms.users import RegisterForm


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/")
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Job).all()
    users = db_sess.query(User).all()
    data = []
    for job in jobs:
        inf = {}
        inf['id'] = job.id
        inf['title'] = job.job
        inf['team leader'] = [f"{user.name} {user.surname}" for user in users if user.id == job.team_leader][0]
        inf['duration'] = job.work_size
        inf['list of collaborators'] = job.collaborators
        inf['is finished'] = 'Is finished' if job.is_finished else 'Is not finished'
        data.append(inf)
    return render_template("index.html", data=data)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Почта занята")
        user = User(
            name=form.name.data,
            email=form.email.data,
            surname=form.surname.data,
            age=form.age.data,
            address=form.address.data,
            position=form.position.data,
            speciality=form.speciality.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return render_template('register.html', title='Регистрация',
                               form=form,
                               message="Вы успешно зарегистрировались")
    return render_template('register.html', title='Регистрация', form=form)


def main():
    db_session.global_init("db/blogs.db")
    app.run()


if __name__ == '__main__':
    main()